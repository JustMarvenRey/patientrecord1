-- Specializations are now deactivated (soft delete) instead of permanently deleted.
-- Run ONCE on an existing database (phpMyAdmin > SQL tab). The app also does this
-- automatically the first time any page calls the API (see api/auto-migrate.php).
ALTER TABLE SPECIALIZATION ADD COLUMN Status VARCHAR(10) NOT NULL DEFAULT 'Active';
