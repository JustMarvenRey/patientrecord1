const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const user = JSON.parse(sessionStorage.getItem("currentUser"));
const isAdmin = user ? user.RoleName === 'Admin' : false;
const isDoctor = user ? user.RoleName === 'Doctor' : false;
// Admin + Staff see every doctor's consultations, so they get the Doctor column
const showDoctorCol = !isDoctor;
const isStaff = user ? user.RoleName === 'Staff' : false; // view-only on this page

document.addEventListener("DOMContentLoaded", () => {
  // Doctor column only exists for Admin + Staff, so only offer that sort to them
  // Changing the sort or a filter goes back to page 1
  const firstPage = () => { pagerState.page = 1; renderSorted(); };
  document.getElementById("sort-by").addEventListener("change", firstPage);
  document.getElementById("hide-completed").addEventListener("change", firstPage);
  document.getElementById("hide-cancelled").addEventListener("change", firstPage);
  displayConsultations();
});

// ── Sorting ─────────────────────────────────────────────────────────────────
let consultationRows = [];
const pagerState = { page: 1, size: 10 };

const cmpRaw = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
const dateTimeKey = (r) => `${r.AppointmentDate} ${r.AppointmentTime ?? ""}`;

const CONSULT_SORTS = {
  // Next up: appointments still waiting for a consultation first, soonest date & time at the
  // top so it is clear who is next; everything else after, newest first.
  "next":             (a, b) => {
    const wa = !a.ConsultationID && a.AppointmentStatus === "Scheduled" ? 0 : 1;
    const wb = !b.ConsultationID && b.AppointmentStatus === "Scheduled" ? 0 : 1;
    if (wa !== wb) return wa - wb;
    const c = cmpRaw(dateTimeKey(a), dateTimeKey(b));
    if (wa === 0) return c || a.AppointmentID - b.AppointmentID;
    return -c || b.AppointmentID - a.AppointmentID;
  },
  "date-desc":        (a, b) => cmpRaw(dateTimeKey(b), dateTimeKey(a)),
  "date-asc":         (a, b) => cmpRaw(dateTimeKey(a), dateTimeKey(b)),
};

const renderSorted = () => {
  const sortKey = document.getElementById("sort-by").value;
  const hideCompleted = document.getElementById("hide-completed").checked;
  const hideCancelled = document.getElementById("hide-cancelled").checked;
  const rows = consultationRows.filter(
    (r) =>
      !(hideCompleted && r.AppointmentStatus === "Completed") &&
      !(hideCancelled && r.AppointmentStatus === "Cancelled")
  );
  const sorted = rows.sort(CONSULT_SORTS[sortKey]);
  renderTable(Pager.paginate(pagerState, sorted));
  Pager.controls(document.getElementById("pager"), pagerState, sorted.length, renderSorted);
};

// ── Fetch & render ─────────────────────────────────────────────────────────
const displayConsultations = async () => {
  if (!user) return;

  const response = await axios.get(`${baseApiUrl}/consultations.php`, {
    params: {
      operation: "getAppointmentsByDoctor",
      json: JSON.stringify({ userId: user.UserID, role: user.RoleName }),
    },
  });

  if (response.status === 200) {
    consultationRows = response.data;
    renderSorted();
  } else {
    alert("Error loading consultations.");
  }
};

const renderTable = (rows) => {
  const tableDiv = document.getElementById("table-div");
  tableDiv.innerHTML = "";

  if (!rows || rows.length === 0) {
    tableDiv.innerHTML = `<p class="text-muted">No appointments found for your account.</p>`;
    return;
  }

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");

  table.innerHTML = `
    <thead>
      <tr>
        <th class="text-nowrap">REQUESTED</th>
        <th>DATE</th>
        <th>TIME</th>
        <th>PATIENT</th>
        ${showDoctorCol ? '<th>DOCTOR</th>' : ''}
        <th>REASON</th>
        <th class="text-nowrap">APPT STATUS</th>
        <th class="text-nowrap">CONSULTATION</th>
        <th class="text-nowrap">ACTION</th>
      </tr>
    </thead>
  `;

  const tbody = document.createElement("tbody");

  rows.forEach((row) => {
    const hasConsultation = !!row.ConsultationID;
    const isInactive = hasConsultation && row.ConsultationStatus === "Inactive";
    const canAdd = isDoctor && ["Confirmed", "Scheduled", "Pending"].includes(row.AppointmentStatus);
    const apptBadge = badgeColor(row.AppointmentStatus);
    const tr = document.createElement("tr");
    if (isInactive) tr.classList.add("table-secondary");

    let consultCell;
    if (!hasConsultation) consultCell = `<span class="badge bg-secondary">None</span>`;
    else if (isInactive) consultCell = `<span class="badge bg-dark">Inactive</span>`;
    else consultCell = `<span class="badge bg-success">Recorded</span>`;

    let actionCell;
    if (hasConsultation) {
      actionCell = `<button class="btn btn-primary btn-sm btn-view-consult">View</button>`;
      if (!isInactive && !isStaff) actionCell += `<button class="btn btn-success btn-sm btn-update-consult">Edit</button>`;
      if (isAdmin) {
        actionCell += isInactive
          ? `<button class="btn btn-warning btn-sm btn-restore-consult">Restore</button>`
          : `<button class="btn btn-danger btn-sm btn-deactivate-consult">Deactivate</button>`;
      }
    } else if (canAdd) {
      actionCell = `<button class="btn btn-warning btn-sm btn-add-consult">Add Consultation</button>`;
    } else {
      actionCell = `<span class="text-muted small">—</span>`;
    }

    tr.innerHTML = `
      <td class="text-nowrap small">${row.CreatedAt ? row.CreatedAt.slice(0, 16).replace("T", " ") : "—"}</td>
      <td class="text-nowrap">${row.AppointmentDate}</td>
      <td class="text-nowrap">${formatTime(row.AppointmentTime)}</td>
      <td>${row.PatientName}</td>
      ${showDoctorCol ? `<td>${row.DoctorName ?? ''}</td>` : ''}
      <td>${row.Reason ?? ""}</td>
      <td><span class="badge ${apptBadge}">${row.AppointmentStatus}</span></td>
      <td>${consultCell}</td>
      <td class="text-nowrap"><div class="d-flex flex-nowrap gap-1">${actionCell}</div></td>
    `;

    tbody.appendChild(tr);

    tr.querySelector(".btn-view-consult")?.addEventListener("click", () => {
      window.location.href = `consultation-detail.html?id=${row.ConsultationID}`;
    });
    tr.querySelector(".btn-update-consult")?.addEventListener("click", () => showConsultationForm(row, true));
    tr.querySelector(".btn-deactivate-consult")?.addEventListener("click", () => deactivateConsultation(row));
    tr.querySelector(".btn-restore-consult")?.addEventListener("click", () => restoreConsultation(row));
    tr.querySelector(".btn-add-consult")?.addEventListener("click", () => showConsultationForm(row, false));
  });

  table.appendChild(tbody);
  const scrollBox = document.createElement("div");
  scrollBox.className = "table-scroll";
  scrollBox.appendChild(table);
  tableDiv.appendChild(scrollBox);
};

// ── Add / Update form modal ─────────────────────────────────────────────────
const showConsultationForm = (row, isUpdate) => {
  const title = isUpdate ? "Edit Consultation" : "Add Consultation";
  document.getElementById("consultation-modal-title").innerText = title;

  const today = Validate.todayStr(); // local date (toISOString would give the UTC date)

  document.getElementById("consultation-modal-body").innerHTML = `
    <div class="mb-2">
      <label class="form-label fw-bold">Patient</label>
      <p class="form-control-plaintext">${row.PatientName}</p>
    </div>
    <div class="mb-2">
      <label class="form-label fw-bold">Appointment</label>
      <p class="form-control-plaintext">${row.AppointmentDate} ${formatTime(row.AppointmentTime)} — ${row.Reason ?? ""}</p>
    </div>
    <div class="mb-2">
      <label class="form-label">Consultation Date <span class="text-danger">*</span></label>
      <input type="date" class="form-control" id="f-consult-date" data-v="consultation.consultationDate" value="${isUpdate ? row.ConsultationDate : today}" />
    </div>
    <div class="mb-2 p-2 rounded border bg-light">
      <div class="small text-muted fw-bold mb-1">Recorded by Staff at intake</div>
      <div class="small"><strong>Chief Complaint:</strong> ${row.ChiefComplaint || '<span class="text-muted">Not recorded yet</span>'}</div>
      <div class="small"><strong>Symptoms:</strong> ${row.Symptoms || '<span class="text-muted">Not recorded yet</span>'}</div>
    </div>
    <div class="mb-2">
      <label class="form-label">Treatment</label>
      <textarea class="form-control" id="f-treatment" data-v="consultation.treatment" rows="2">${isUpdate ? (row.Treatment ?? "") : ""}</textarea>
    </div>
    <div class="mb-2">
      <label class="form-label">Notes</label>
      <textarea class="form-control" id="f-notes" data-v="consultation.notes" rows="2">${isUpdate ? (row.ConsultationNotes ?? "") : ""}</textarea>
    </div>
  `;

  const footer = document.getElementById("consultation-modal-footer");
  footer.innerHTML = `
    <button type="button" class="btn btn-success btn-sm me-2" id="btn-save-consult">
      ${isUpdate ? "Save Changes" : "Save Consultation"}
    </button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("consultation-modal"), { backdrop: "static" });
  modal.show();

  document.getElementById("btn-save-consult").addEventListener("click", async () => {
    const payload = {
      consultationDate: document.getElementById("f-consult-date").value,
      treatment: document.getElementById("f-treatment").value,
      notes:     document.getElementById("f-notes").value,
    };
    if (!Validate.ok("consultation", payload)) return;
    if (payload.consultationDate < row.AppointmentDate) {
      alert(`Consultation date must not be earlier than the appointment date (${row.AppointmentDate}).`);
      return;
    }

    const result = isUpdate
      ? await updateConsultation({ consultationId: row.ConsultationID, ...payload })
      : await insertConsultation({ appointmentId: row.AppointmentID, ...payload });

    if (!isUpdate && result?.success == 1) {
      // New consultation → go to the detail page for diagnosis + prescriptions next
      modal.hide();
      window.location.href = `consultation-detail.html?id=${result.consultationId}&new=1`;
    } else if (isUpdate && result == 1) {
      modal.hide();
      displayConsultations();
      alert("Consultation updated!");
    } else if (result?.error === "already_has_consultation") {
      alert("This appointment already has a consultation recorded.");
    } else {
      alert("ERROR saving consultation.");
    }
  });
};

// ── API calls ───────────────────────────────────────────────────────────────
const insertConsultation = async (data) => {
  const fd = new FormData();
  fd.append("operation", "insertConsultation");
  fd.append("json", JSON.stringify(data));
  const res = await axios({ url: `${baseApiUrl}/consultations.php`, method: "POST", data: fd });
  return res.data;
};

const updateConsultation = async (data) => {
  const fd = new FormData();
  fd.append("operation", "updateConsultation");
  fd.append("json", JSON.stringify(data));
  const res = await axios({ url: `${baseApiUrl}/consultations.php`, method: "POST", data: fd });
  return res.data;
};

// ── Deactivate / Restore (Admin only) ───────────────────────────────────────
const CONSULT_ERRORS = { forbidden: "Only an Admin can do that." };

const postConsultStatus = async (operation, row) => {
  const fd = new FormData();
  fd.append("operation", operation);
  fd.append("json", JSON.stringify({ consultationId: row.ConsultationID, actingUserId: user.UserID }));
  const res = await axios({ url: `${baseApiUrl}/consultations.php`, method: "POST", data: fd });
  return res.data;
};

const deactivateConsultation = async (row) => {
  const ok = await showConfirm(
    `Deactivate the consultation for ${row.PatientName} (${row.AppointmentDate})? The record is kept and can be restored later.`,
    { type: "danger", title: "Deactivate consultation", confirmText: "Deactivate", cancelText: "Keep" }
  );
  if (!ok) return;
  const res = await postConsultStatus("deactivateConsultation", row);
  if (res == 1) {
    displayConsultations();
    alert("Consultation has been deactivated!");
  } else {
    alert(CONSULT_ERRORS[res?.error] || "ERROR deactivating consultation.");
  }
};

const restoreConsultation = async (row) => {
  const res = await postConsultStatus("restoreConsultation", row);
  if (res == 1) {
    displayConsultations();
    alert("Consultation restored!");
  } else {
    alert(CONSULT_ERRORS[res?.error] || "ERROR restoring consultation.");
  }
};

// ── Helpers ─────────────────────────────────────────────────────────────────
const formatTime = (t) => {
  if (!t) return "";
  const [h, m] = t.split(":");
  const hr = parseInt(h);
  return `${hr % 12 || 12}:${m} ${hr < 12 ? "AM" : "PM"}`;
};

const badgeColor = (status) => {
  switch (status) {
    case "Completed":  return "bg-success";
    case "Scheduled":  return "bg-primary";
    case "Confirmed":  return "bg-info text-dark";
    case "Pending":    return "bg-warning text-dark";
    case "Cancelled":  return "bg-danger";
    case "No-Show":    return "bg-warning text-dark";
    default:           return "bg-secondary";
  }
};
