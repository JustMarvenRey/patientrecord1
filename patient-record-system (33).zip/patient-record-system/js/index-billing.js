import { cmpText, cmpNum, cmpRaw, sortBySelect } from "./sort-utils.js?v=20261022";
import {
  actingUserId, canManageBills, canManageFees, isAdminRole, esc, peso, statusBadge,
  postBilling, getBilling, checkBillingResult,
} from "./modules-billing/common.js?v=20261022";

const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const SORTS = {
  "date-desc":    (a, b) => cmpRaw(b.BillDate, a.BillDate),
  "date-asc":     (a, b) => cmpRaw(a.BillDate, b.BillDate),
  "patient-asc":  (a, b) => cmpText(a.PatientName, b.PatientName),
  "patient-desc": (a, b) => cmpText(b.PatientName, a.PatientName),
  "doctor-asc":   (a, b) => cmpText(a.DoctorName, b.DoctorName),
  "total-desc":   (a, b) => cmpNum(b.TotalAmount, a.TotalAmount),
  "total-asc":    (a, b) => cmpNum(a.TotalAmount, b.TotalAmount),
  "fees-desc":    (a, b) => cmpNum(b.FeesTotal, a.FeesTotal),
};

const todayStr = () => Validate.todayStr(); // local date (toISOString would give the UTC date)

document.addEventListener("DOMContentLoaded", () => {
  const canFees = canManageFees();
  document.getElementById("billing-subtext").textContent = canFees
    ? "View and manage all patient bills and professional fees."
    : "View patient bills and professional fees.";

  if (canManageBills()) {
    const btn = document.getElementById("btn-create-bill");
    btn.classList.remove("d-none");
    btn.addEventListener("click", showCreateBillModal);
  }

  document.getElementById("status-filter").addEventListener("change", renderTable);
  document.getElementById("sort-by").addEventListener("change", renderTable);
  displayBills();
});

let allBills = [];

// ── Fetch & render all bills ────────────────────────────────────────────────
const displayBills = async () => {
  const data = await getBilling(baseApiUrl, "getAllBills");
  if (!Array.isArray(data)) {
    alert(data?.error === "forbidden" ? "Your role isn't allowed to view billing." : "Error loading billing records.");
    return;
  }
  allBills = data;
  renderTable();
};

const renderTable = () => {
  const filter = document.getElementById("status-filter").value;
  const rows = sortBySelect(allBills.filter((b) => !filter || b.Status === filter), SORTS);

  const tableDiv = document.getElementById("table-div");
  tableDiv.innerHTML = "";

  if (rows.length === 0) {
    tableDiv.innerHTML = `<p class="text-muted">No bills found.</p>`;
    return;
  }

  const table = document.createElement("table");
  table.className = "table table-hover table-striped table-sm";
  table.innerHTML = `
    <thead>
      <tr>
        <th>BILL DATE</th>
        <th>PATIENT</th>
        <th>DOCTOR</th>
        <th>APPT DATE</th>
        <th>TOTAL (₱)</th>
        <th class="text-nowrap">PROF. FEES (₱)</th>
        <th>STATUS</th>
        <th class="text-nowrap">ACTION</th>
      </tr>
    </thead>
  `;

  const tbody = document.createElement("tbody");
  rows.forEach((row) => {
    const tr = document.createElement("tr");
    const isCancelled = row.Status === "Cancelled";
    if (isCancelled) tr.classList.add("table-secondary");
    tr.innerHTML = `
      <td>${esc(row.BillDate)}</td>
      <td>${esc(row.PatientName)}</td>
      <td>${esc(row.DoctorName)}</td>
      <td>${esc(row.AppointmentDate)}</td>
      <td>${(parseFloat(row.TotalAmount) || 0).toFixed(2)}</td>
      <td>${
        Number(row.FeesCount) > 0
          ? `${(parseFloat(row.FeesTotal) || 0).toFixed(2)}<div class="small text-muted">${row.FeesCount} fee${Number(row.FeesCount) === 1 ? "" : "s"}</div>`
          : `<span class="text-muted">—</span>`
      }</td>
      <td><span class="badge ${statusBadge(row.Status)}">${esc(row.Status)}</span></td>
      <td class="text-nowrap" style="width: 1%;">
        <div class="d-flex flex-nowrap gap-1">
          <button class="btn btn-primary btn-sm btn-view">View</button>
          ${canManageBills() ? `<button class="btn btn-success btn-sm btn-edit">Edit</button>` : ""}
          ${isAdminRole()
            ? (isCancelled
                ? `<button class="btn btn-warning btn-sm btn-restore">Restore</button>`
                : `<button class="btn btn-danger btn-sm btn-deactivate">Deactivate</button>`)
            : ""}
        </div>
      </td>
    `;
    tbody.appendChild(tr);

    tr.querySelector(".btn-view").addEventListener("click", () => viewBill(row));
    tr.querySelector(".btn-edit")?.addEventListener("click", () => showEditBillModal(row));
    tr.querySelector(".btn-deactivate")?.addEventListener("click", () => deactivateBill(row));
    tr.querySelector(".btn-restore")?.addEventListener("click", () => restoreBill(row));
  });

  table.appendChild(tbody);
  const scrollBox = document.createElement("div");
  scrollBox.className = "table-scroll";
  scrollBox.appendChild(table);
  tableDiv.appendChild(scrollBox);
};

// ── Deactivate / Restore (Admin only) ───────────────────────────────────────
const deactivateBill = async (bill) => {
  const ok = await showConfirm(
    `Deactivate the bill for ${bill.PatientName} (${bill.BillDate})? It will be marked Cancelled and can be restored later.`,
    { type: "danger", title: "Deactivate bill", confirmText: "Deactivate", cancelText: "Keep" }
  );
  if (!ok) return;
  const res = await postBilling(baseApiUrl, "deactivateBilling", { billId: bill.BillID });
  if (checkBillingResult(res, "Bill has been deactivated!")) displayBills();
};

const restoreBill = async (bill) => {
  const res = await postBilling(baseApiUrl, "restoreBilling", { billId: bill.BillID });
  if (checkBillingResult(res, "Bill restored (set back to Pending).")) displayBills();
};

// ── View Bill modal (with fees) ─────────────────────────────────────────────
const viewBill = async (bill) => {
  document.getElementById("bill-modal-title").innerText = `Bill — ${bill.PatientName}`;

  const fees = await getBilling(baseApiUrl, "getProfessionalFees", { billId: bill.BillID });
  const feeList = Array.isArray(fees) ? fees : [];
  const feesTotal = feeList.reduce((sum, f) => sum + (parseFloat(f.FeeAmount) || 0), 0);
  const canFees = canManageFees();

  const feesHtml = feeList.length > 0
    ? `<table class="table table-sm mt-2">
        <thead><tr><th>Doctor</th><th>Description</th><th>Amount (₱)</th>${canFees ? "<th>Action</th>" : ""}</tr></thead>
        <tbody>
          ${feeList.map((f) => `
            <tr>
              <td>${esc(f.DoctorName)}</td>
              <td class="text-muted small">${esc(f.Description ?? "—")}</td>
              <td>${(parseFloat(f.FeeAmount) || 0).toFixed(2)}</td>
              ${canFees ? `<td><button class="btn btn-danger btn-sm btn-remove-fee" data-id="${f.ProfessionalFeeID}">Remove</button></td>` : ""}
            </tr>`).join("")}
        </tbody>
        <tfoot>
          <tr><th colspan="2" class="text-end">Fees subtotal</th><th>${feesTotal.toFixed(2)}</th>${canFees ? "<th></th>" : ""}</tr>
        </tfoot>
       </table>`
    : `<p class="text-muted small">No professional fees recorded.</p>`;

  document.getElementById("bill-modal-body").innerHTML = `
    <table class="table table-sm mb-3">
      <tr><td><strong>Patient</strong></td><td>${esc(bill.PatientName)}</td></tr>
      <tr><td><strong>Doctor</strong></td><td>${esc(bill.DoctorName)}</td></tr>
      <tr><td><strong>Appointment Date</strong></td><td>${esc(bill.AppointmentDate)}</td></tr>
      <tr><td><strong>Bill Date</strong></td><td>${esc(bill.BillDate)}</td></tr>
      <tr><td><strong>Total Amount</strong></td><td>${peso(bill.TotalAmount)}</td></tr>
      <tr><td><strong>Status</strong></td><td><span class="badge ${statusBadge(bill.Status)}">${esc(bill.Status)}</span></td></tr>
    </table>
    <div class="d-flex justify-content-between align-items-center mb-2">
      <strong>Professional Fees</strong>
      ${canFees ? `<button class="btn btn-success btn-sm" id="btn-add-fee-view">+ Add Fee</button>` : ""}
    </div>
    ${feesHtml}
  `;

  document.getElementById("bill-modal-footer").innerHTML = `
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("bill-modal"), { backdrop: "static" });
  modal.show();

  document.getElementById("btn-add-fee-view")?.addEventListener("click", () => {
    modal.hide();
    showAddFeeModal(bill.BillID);
  });

  document.querySelectorAll(".btn-remove-fee").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!(await showConfirm("Remove this fee?", { type: "danger", title: "Remove fee", confirmText: "Remove" }))) return;
      const res = await postBilling(baseApiUrl, "removeProfessionalFee", { professionalFeeId: btn.dataset.id });
      if (checkBillingResult(res)) { modal.hide(); displayBills(); }
    });
  });
};

// ── Create Bill modal (Admin + Staff) ───────────────────────────────────────
const showCreateBillModal = async () => {
  const consultations = await getBilling(baseApiUrl, "getUnbilledConsultations");
  if (!Array.isArray(consultations)) {
    checkBillingResult(consultations);
    return;
  }

  const docRes = await axios.get(`${baseApiUrl}/billing.php`, { params: { operation: "getActiveDoctors" } });
  const doctors = Array.isArray(docRes.data) ? docRes.data : [];
  const consultationById = Object.fromEntries(consultations.map((c) => [String(c.ConsultationID), c]));

  const options = consultations
    .map((c) => `<option value="${c.ConsultationID}">${esc(c.ConsultationDate)} — ${esc(c.PatientName)} (Dr. ${esc(c.DoctorName)})</option>`)
    .join("");

  document.getElementById("create-bill-modal-body").innerHTML = consultations.length === 0
    ? `<p class="text-muted mb-0">Every consultation already has a bill.</p>`
    : `
      <div class="mb-2">
        <label class="form-label">Consultation <span class="text-danger">*</span></label>
        <select class="form-select" id="create-bill-consultation" data-v="bill.consultationId">
          <option value="" disabled selected>-- Select consultation --</option>
          ${options}
        </select>
        <div class="form-text">Only consultations that don't have a bill yet are listed.</div>
      </div>
      <div class="mb-2">
        <label class="form-label">Bill Date <span class="text-danger">*</span></label>
        <input type="date" class="form-control" id="create-bill-date" data-v="bill.billDate" value="${todayStr()}" />
      </div>
      <div class="mb-2">
        <label class="form-label">Total Amount (₱) <span class="text-danger">*</span></label>
        <input type="number" min="0" step="0.01" class="form-control" id="create-bill-amount" data-v="bill.totalAmount" placeholder="0.00" />
      </div>
      <hr class="my-3" />
      <div class="d-flex justify-content-between align-items-center mb-2">
        <strong>Professional Fees <span class="text-muted fw-normal small">(optional)</span></strong>
        <button type="button" class="btn btn-success btn-sm" id="btn-add-fee-row">+ Add Fee</button>
      </div>
      <div id="fee-rows"></div>
      <div class="form-text" id="fee-rows-empty">No professional fees added.</div>
    `;

  document.getElementById("create-bill-modal-footer").innerHTML = `
    ${consultations.length > 0 ? `<button type="button" class="btn btn-success btn-sm me-2" id="btn-save-create-bill">Create Bill</button>` : ""}
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("create-bill-modal"), { backdrop: "static" });
  modal.show();

  // ── Professional fee rows (optional) ──
  const feeRows = document.getElementById("fee-rows");
  const feeEmpty = document.getElementById("fee-rows-empty");
  const refreshFeeEmpty = () => {
    if (feeEmpty) feeEmpty.style.display = feeRows.children.length ? "none" : "";
  };

  const addFeeRow = () => {
    // default the doctor to the one on the selected consultation
    const picked = consultationById[document.getElementById("create-bill-consultation").value];
    const defaultDoctor = picked ? String(picked.DoctorID) : "";
    const docOptions = doctors
      .map((d) => `<option value="${d.UserID}" ${String(d.UserID) === defaultDoctor ? "selected" : ""}>${esc(d.DoctorName)}</option>`)
      .join("");

    const row = document.createElement("div");
    row.className = "row g-2 align-items-center mb-2 fee-row";
    row.innerHTML = `
      <div class="col-md-4">
        <select class="form-select fee-row-doctor" aria-label="Doctor">
          <option value="">-- Doctor --</option>
          ${docOptions}
        </select>
      </div>
      <div class="col-md-3">
        <input type="number" min="0.01" step="0.01" class="form-control fee-row-amount" placeholder="Amount (₱)" aria-label="Fee amount" />
      </div>
      <div class="col-md-4">
        <input type="text" class="form-control fee-row-desc" placeholder="Description" aria-label="Fee description" />
      </div>
      <div class="col-md-1 text-end">
        <button type="button" class="btn btn-outline-danger btn-sm fee-row-remove" title="Remove fee">&times;</button>
      </div>
    `;
    row.querySelector(".fee-row-remove").addEventListener("click", () => {
      row.remove();
      refreshFeeEmpty();
    });
    feeRows.appendChild(row);
    refreshFeeEmpty();
  };
  document.getElementById("btn-add-fee-row")?.addEventListener("click", addFeeRow);

  document.getElementById("btn-save-create-bill")?.addEventListener("click", async () => {
    const consultationId = document.getElementById("create-bill-consultation").value;
    const billDate = document.getElementById("create-bill-date").value;
    const totalAmount = document.getElementById("create-bill-amount").value;
    if (!Validate.ok("bill", { consultationId, billDate, totalAmount })) return;

    // Collect fee rows (completely empty rows are ignored)
    const fees = [];
    for (const row of feeRows.querySelectorAll(".fee-row")) {
      const userId = row.querySelector(".fee-row-doctor").value;
      const feeAmount = row.querySelector(".fee-row-amount").value;
      const description = row.querySelector(".fee-row-desc").value.trim();
      if (!userId && feeAmount === "" && !description) continue;
      const feeErr = Validate.check("fee", { userId, feeAmount, description });
      if (feeErr) { alert(`Professional fee: ${feeErr}`); return; }
      fees.push({ userId, feeAmount, description: description || null });
    }

    const res = await postBilling(baseApiUrl, "insertBilling", { consultationId, billDate, totalAmount });
    if (!res?.billId) { checkBillingResult(res); return; }

    let failed = 0;
    for (const fee of fees) {
      const feeRes = await postBilling(baseApiUrl, "insertProfessionalFee", { billId: res.billId, ...fee });
      if (feeRes != 1) failed++;
    }

    if (failed > 0) {
      alert(`Bill created, but ${failed} professional fee(s) could not be added. You can add them from the bill's View window.`);
    } else {
      alert(fees.length ? `Bill created with ${fees.length} professional fee(s)!` : "Bill created!");
    }
    modal.hide();
    displayBills();
  });
};

// ── Edit Bill modal (Admin + Staff) ─────────────────────────────────────────
const showEditBillModal = (bill) => {
  const statusOptions = ["Pending", "Paid", "Cancelled"].map((s) =>
    `<option value="${s}" ${bill.Status === s ? "selected" : ""}>${s}</option>`
  ).join("");

  document.getElementById("edit-bill-modal-body").innerHTML = `
    <div class="mb-2">
      <label class="form-label"><strong>Patient:</strong> ${esc(bill.PatientName)}</label>
    </div>
    <div class="mb-2">
      <label class="form-label">Bill Date <span class="text-danger">*</span></label>
      <input type="date" class="form-control" id="edit-bill-date" data-v="bill_update.billDate" value="${esc(bill.BillDate)}" />
    </div>
    <div class="mb-2">
      <label class="form-label">Total Amount (₱) <span class="text-danger">*</span></label>
      <input type="number" min="0" step="0.01" class="form-control" id="edit-bill-amount" data-v="bill_update.totalAmount" value="${esc(bill.TotalAmount)}" />
    </div>
    <div class="mb-2">
      <label class="form-label">Status</label>
      <select class="form-select" id="edit-bill-status" data-v="bill_update.status">${statusOptions}</select>
      <div class="form-text">Set to <strong>Paid</strong> once the patient has paid.</div>
    </div>
  `;

  document.getElementById("edit-bill-modal-footer").innerHTML = `
    <button type="button" class="btn btn-success btn-sm me-2" id="btn-save-edit-bill">Save Changes</button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("edit-bill-modal"), { backdrop: "static" });
  modal.show();

  document.getElementById("btn-save-edit-bill").addEventListener("click", async () => {
    const billDate    = document.getElementById("edit-bill-date").value;
    const totalAmount = document.getElementById("edit-bill-amount").value;
    const status      = document.getElementById("edit-bill-status").value;
    if (!Validate.ok("bill_update", { billDate, totalAmount, status })) return;

    const res = await postBilling(baseApiUrl, "updateBilling", { billId: bill.BillID, billDate, totalAmount, status });
    if (checkBillingResult(res)) { modal.hide(); displayBills(); }
  });
};

// ── Add Professional Fee modal (Admin only) ─────────────────────────────────
const showAddFeeModal = async (billId) => {
  const docRes = await axios.get(`${baseApiUrl}/billing.php`, { params: { operation: "getActiveDoctors" } });
  const docOptions = docRes.data.map((d) =>
    `<option value="${d.UserID}">${esc(d.DoctorName)}</option>`
  ).join("");

  document.getElementById("fee-modal-body").innerHTML = `
    <div class="mb-2">
      <label class="form-label">Doctor <span class="text-danger">*</span></label>
      <select class="form-select" id="fee-doctor" data-v="fee.userId">
        <option value="" disabled selected>-- Select Doctor --</option>
        ${docOptions}
      </select>
    </div>
    <div class="mb-2">
      <label class="form-label">Fee Amount (₱) <span class="text-danger">*</span></label>
      <input type="number" min="0.01" step="0.01" class="form-control" id="fee-amount" data-v="fee.feeAmount" placeholder="0.00" />
    </div>
    <div class="mb-2">
      <label class="form-label">Description</label>
      <input type="text" class="form-control" id="fee-description" data-v="fee.description" placeholder="e.g. Consultation fee" />
    </div>
  `;

  document.getElementById("fee-modal-footer").innerHTML = `
    <button type="button" class="btn btn-success btn-sm me-2" id="btn-save-fee">Add Fee</button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("fee-modal"), { backdrop: "static" });
  modal.show();

  document.getElementById("btn-save-fee").addEventListener("click", async () => {
    const userId    = document.getElementById("fee-doctor").value;
    const feeAmount = document.getElementById("fee-amount").value;
    const description = document.getElementById("fee-description").value;
    if (!Validate.ok("fee", { userId, feeAmount, description })) return;

    const res = await postBilling(baseApiUrl, "insertProfessionalFee", {
      billId,
      userId,
      feeAmount,
      description: description.trim() || null,
    });
    if (checkBillingResult(res)) { modal.hide(); displayBills(); }
  });
};
