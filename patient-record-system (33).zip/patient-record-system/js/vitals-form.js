// Shared Staff "Patient Intake" modal: Reason, Chief Complaint, Symptoms + Vital Signs.
// Plain script (like popup.js): exposes window.showIntakeModal.
// The doctor sees all of this automatically in the consultation.
//
//   showIntakeModal({ appointmentId, patientName, dateLabel, intake, vitals, onSaved })
//     intake  → { reason, chiefComplaint, symptoms } already on the appointment
//     vitals  → existing vital-sign record (edit) or null (record)
//     returns a Promise<boolean> — true if saved, false if cancelled
(() => {
  const API = () => sessionStorage.getItem("baseAPIUrl") || "http://localhost/patient-record-system/api";
  const esc = (t) => String(t ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  const field = (id, label, type, extra, value, placeholder, col = "col-md-6") => `
    <div class="${col}">
      <label class="form-label">${label}</label>
      <input type="${type}" ${extra} class="form-control" id="${id}"
             value="${esc(value)}" placeholder="${placeholder}" />
    </div>`;

  window.showIntakeModal = ({ appointmentId, patientName, dateLabel, intake, vitals, onSaved }) => {
    const hasVitals = !!vitals;
    const v = vitals || {};
    const i = intake || {};
    const isEdit = hasVitals || !!i.chiefComplaint;
    const user = JSON.parse(sessionStorage.getItem("currentUser") ?? "null");

    document.getElementById("intake-modal-shared")?.remove();
    const wrap = document.createElement("div");
    wrap.innerHTML = `
      <div class="modal fade" id="intake-modal-shared" role="dialog">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">${isEdit ? "Edit Patient Intake" : "Patient Intake"}</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <p class="text-muted small mb-3">
                Patient: <strong>${esc(patientName)}</strong> &nbsp;|&nbsp;
                Appointment: <strong>${esc(dateLabel)}</strong>
              </p>

              <h6 class="mb-2">Reason &amp; Complaint</h6>
              <div class="row g-3 mb-4">
                <div class="col-12">
                  <label class="form-label">Reason for visit</label>
                  <input type="text" class="form-control" id="ik-reason" value="${esc(i.reason)}" placeholder="e.g. Migraine" />
                </div>
                <div class="col-12">
                  <label class="form-label">Chief Complaint <span class="text-danger">*</span></label>
                  <textarea class="form-control" id="ik-chief" rows="2" placeholder="Main problem in the patient's words">${esc(i.chiefComplaint)}</textarea>
                </div>
                <div class="col-12">
                  <label class="form-label">Symptoms</label>
                  <textarea class="form-control" id="ik-symptoms" rows="2" placeholder="e.g. dizziness, nausea">${esc(i.symptoms)}</textarea>
                </div>
              </div>

              <h6 class="mb-2">Vital Signs</h6>
              <div class="row g-3">
                ${field("ik-temperature", "Temperature (°C)", "number", 'step="0.1" min="30" max="45"', v.Temperature, "e.g. 36.8")}
                ${field("ik-blood-pressure", "Blood Pressure (mmHg)", "text", "", v.BloodPressure, "e.g. 120/80")}
                ${field("ik-heart-rate", "Heart Rate (bpm)", "number", 'min="0" max="300"', v.HeartRate, "e.g. 72")}
                ${field("ik-respiratory-rate", "Respiratory Rate (breaths/min)", "number", 'min="0" max="60"', v.RespiratoryRate, "e.g. 16")}
                ${field("ik-oxygen", "O₂ Saturation (%)", "number", 'min="0" max="100"', v.OxygenSaturation, "e.g. 98")}
                ${field("ik-weight", "Weight (kg)", "number", 'step="0.1" min="0" max="500"', v.Weight, "e.g. 65.5", "col-md-3")}
                ${field("ik-height", "Height (cm)", "number", 'step="0.1" min="0" max="300"', v.Height, "e.g. 165.0", "col-md-3")}
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-success btn-sm me-2" id="ik-save">
                ${isEdit ? "Save Changes" : "Save Intake"}
              </button>
              <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
            </div>
          </div>
        </div>
      </div>`;
    // Input limits + inline messages (see validators.js)
    Object.entries({
      "ik-reason": "intake.reason", "ik-chief": "intake.chiefComplaint", "ik-symptoms": "intake.symptoms",
      "ik-temperature": "vitals.temperature", "ik-blood-pressure": "vitals.bloodPressure",
      "ik-heart-rate": "vitals.heartRate", "ik-respiratory-rate": "vitals.respiratoryRate",
      "ik-oxygen": "vitals.oxygenSaturation", "ik-weight": "vitals.weight", "ik-height": "vitals.height",
    }).forEach(([id, key]) => wrap.querySelector("#" + id)?.setAttribute("data-v", key));
    document.body.appendChild(wrap.firstElementChild);

    const el = document.getElementById("intake-modal-shared");
    const modal = new bootstrap.Modal(el, { backdrop: "static" });
    let saved = false;
    const closed = new Promise((resolve) =>
      el.addEventListener("hidden.bs.modal", () => { el.remove(); resolve(saved); }, { once: true })
    );
    modal.show();

    const post = async (url, operation, data) => {
      const fd = new FormData();
      fd.append("operation", operation);
      fd.append("json", JSON.stringify(data));
      return (await axios({ url: `${API()}/${url}`, method: "POST", data: fd })).data;
    };

    document.getElementById("ik-save").addEventListener("click", async () => {
      const val = (id) => document.getElementById(id).value.trim() || null;
      const chief = val("ik-chief");

      const readings = {
        temperature:      val("ik-temperature"),
        bloodPressure:    val("ik-blood-pressure"),
        heartRate:        val("ik-heart-rate"),
        respiratoryRate:  val("ik-respiratory-rate"),
        oxygenSaturation: val("ik-oxygen"),
        weight:           val("ik-weight"),
        height:           val("ik-height"),
      };
      const hasReadings = Object.values(readings).some((x) => x !== null);

      // Validate EVERYTHING before sending anything, so a bad vital sign can't leave a half-saved intake.
      if (!Validate.ok("intake", { reason: val("ik-reason"), chiefComplaint: chief, symptoms: val("ik-symptoms") })) return;
      if (!Validate.ok("vitals", readings)) return;

      // 1. Reason / chief complaint / symptoms -> appointment
      const r1 = await post("appointments.php", "saveIntake", {
        actingUserId: user?.UserID, appointmentId,
        reason: val("ik-reason"), chiefComplaint: chief, symptoms: val("ik-symptoms"),
      });
      if (r1 != 1) {
        alert(r1?.error === "forbidden" ? "Only Staff can record the intake."
            : r1?.error === "appointment_cancelled" ? "This appointment is cancelled."
            : "ERROR saving intake.");
        return;
      }

      // 2. Vital signs (optional) -> create or update
      if (hasReadings) {
        const data = { actingUserId: user?.UserID, appointmentId, ...readings };
        if (hasVitals) data.vitalSignId = v.VitalSignID;
        const r2 = await post("vital-signs.php", hasVitals ? "updateVitalSign" : "insertVitalSign", data);
        if (r2 != 1) {
          alert(r2?.error === "forbidden" ? "Only Staff can record vital signs."
              : "The complaint was saved, but ERROR saving vital signs.");
          return;
        }
      }

      saved = true;
      modal.hide();
      alert("Patient intake saved!");
      if (onSaved) onSaved();
    });

    return closed;
  };
})();
