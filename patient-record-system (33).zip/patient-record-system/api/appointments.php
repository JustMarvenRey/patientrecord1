<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
require_once __DIR__ . "/validation.php";

class Appointment {

    // All appointments — Admin/Staff view (full list, all doctors)
    function getAllAppointments() {
        include "connection-pdo.php";
        $sql = "SELECT
                    a.AppointmentID,
                    a.AppointmentDate,
                    a.AppointmentTime,
                    a.Reason,
                    a.Status,
                    a.Notes,
                    a.ChiefComplaint,
                    a.Symptoms,
                    a.CreatedAt,
                    CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                    p.PatientID,
                    CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                    u.UserID,
                    (SELECT COUNT(*) FROM VITAL_SIGN v
                      WHERE v.AppointmentID = a.AppointmentID AND v.Status = 'Active') AS HasVitals,
                    (a.ChiefComplaint IS NOT NULL AND a.ChiefComplaint <> '') AS HasIntake
                FROM APPOINTMENT a
                JOIN PATIENT p ON a.PatientID = p.PatientID
                JOIN USERS   u ON a.UserID    = u.UserID
                ORDER BY a.AppointmentDate DESC, a.AppointmentTime DESC";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Appointments for a specific doctor (Doctor view)
    function getAppointmentsByDoctor($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT
                    a.AppointmentID,
                    a.AppointmentDate,
                    a.AppointmentTime,
                    a.Reason,
                    a.Status,
                    a.Notes,
                    a.ChiefComplaint,
                    a.Symptoms,
                    a.CreatedAt,
                    CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                    p.PatientID,
                    CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                    u.UserID,
                    (SELECT COUNT(*) FROM VITAL_SIGN v
                      WHERE v.AppointmentID = a.AppointmentID AND v.Status = 'Active') AS HasVitals,
                    (a.ChiefComplaint IS NOT NULL AND a.ChiefComplaint <> '') AS HasIntake
                FROM APPOINTMENT a
                JOIN PATIENT p ON a.PatientID = p.PatientID
                JOIN USERS   u ON a.UserID    = u.UserID
                WHERE a.UserID = :userId
                ORDER BY a.AppointmentDate DESC, a.AppointmentTime DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":userId", $json['userId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Single appointment detail
    function getAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT
                    a.*,
                    CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                    CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName
                FROM APPOINTMENT a
                JOIN PATIENT p ON a.PatientID = p.PatientID
                JOIN USERS   u ON a.UserID    = u.UserID
                WHERE a.AppointmentID = :appointmentId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":appointmentId", $json['appointmentId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Get all active doctors for the doctor dropdown
    function getActiveDoctors() {
        include "connection-pdo.php";
        $sql = "SELECT u.UserID,
                       CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                       GROUP_CONCAT(s.SpecializationName ORDER BY s.SpecializationName SEPARATOR ', ') AS Specializations
                FROM USERS u
                JOIN ROLE r ON u.RoleID = r.RoleID
                LEFT JOIN DOCTOR_SPECIALIZATION ds ON ds.UserID = u.UserID
                LEFT JOIN SPECIALIZATION s ON s.SpecializationID = ds.SpecializationID
                WHERE r.RoleName = 'Doctor' AND u.Status = 'Active'
                GROUP BY u.UserID, u.LastName, u.FirstName
                ORDER BY u.LastName, u.FirstName";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // True when $date (YYYY-MM-DD) is a real date and is today or later.
    private function isTodayOrFuture($date) {
        $d = DateTime::createFromFormat('Y-m-d', $date ?? '');
        if (!$d || $d->format('Y-m-d') !== $date) return false;
        return $date >= date('Y-m-d');
    }

    // Create — available to Staff, Doctor, and Patient (all roles)
    // Double-booking guard: the same doctor, or the same patient, can't have two Scheduled
    // appointments at the same date and time (Cancelled ones don't count).
    private function findConflict($conn, $json, $excludeId = null) {
        foreach ([["UserID", "That doctor"], ["PatientID", "That patient"]] as $pair) {
            $col = $pair[0];
            $key = $col === "UserID" ? "userId" : "patientId";
            $sql = "SELECT COUNT(*) FROM APPOINTMENT
                    WHERE $col = :who AND AppointmentDate = :d AND AppointmentTime = :t AND Status = 'Scheduled'";
            if ($excludeId !== null) $sql .= " AND AppointmentID != :id";
            $st = $conn->prepare($sql);
            $st->bindValue(":who", $json[$key]);
            $st->bindValue(":d", $json['appointmentDate']);
            $st->bindValue(":t", $json['appointmentTime']);
            if ($excludeId !== null) $st->bindValue(":id", $excludeId);
            $st->execute();
            if ((int)$st->fetchColumn() > 0) {
                return "{$pair[1]} already has a scheduled appointment on {$json['appointmentDate']} at {$json['appointmentTime']}. Please choose a different time.";
            }
        }
        return null;
    }

    function insertAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);

        list($err, $json) = Validator::run("appointment", $json);
        if ($err) return Validator::fail($err);

        // The patient must exist and be Active; the doctor must be an Active user with the Doctor role.
        $pc = $conn->prepare("SELECT COUNT(*) FROM PATIENT WHERE PatientID = :id AND Status = 'Active'");
        $pc->bindValue(":id", $json['patientId']); $pc->execute();
        if ((int)$pc->fetchColumn() === 0) return Validator::fail("That patient is not available. Please select an active patient.");
        $dc = $conn->prepare("SELECT COUNT(*) FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                              WHERE u.UserID = :id AND u.Status = 'Active' AND r.RoleName = 'Doctor'");
        $dc->bindValue(":id", $json['userId']); $dc->execute();
        if ((int)$dc->fetchColumn() === 0) return Validator::fail("That doctor is not available. Please select an active doctor.");
        if ($e = Validator::timePassedToday($json['appointmentDate'], $json['appointmentTime'])) return Validator::fail($e);
        if ($e = $this->findConflict($conn, $json)) return Validator::fail($e);

        // CreatedAt = the moment the request was submitted (shown as "Requested"; lists are sorted by appointment time).
        $sql = "INSERT INTO APPOINTMENT
                    (PatientID, UserID, AppointmentDate, AppointmentTime, Reason, Notes, Status, CreatedAt)
                VALUES
                    (:patientId, :userId, :appointmentDate, :appointmentTime, :reason, :notes, 'Scheduled', NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":patientId",       $json['patientId']);
        $stmt->bindParam(":userId",          $json['userId']);
        $stmt->bindParam(":appointmentDate", $json['appointmentDate']);
        $stmt->bindParam(":appointmentTime", $json['appointmentTime']);
        $stmt->bindParam(":reason",          $json['reason']);
        $stmt->bindParam(":notes",           $json['notes']);
        $stmt->execute();

        if ($stmt->rowCount() > 0 && !empty($json['returnId'])) {
            // Lets the Staff UI go straight on to the intake
            return json_encode(["appointmentId" => (int)$conn->lastInsertId()]);
        }
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }

    // Update — Admin and Staff only
    function updateAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);

        if ($e = Validator::badId($json, ['appointmentId'])) return Validator::fail($e);
        $cur = $conn->prepare("SELECT AppointmentDate, TIME_FORMAT(AppointmentTime, '%H:%i') AS T FROM APPOINTMENT WHERE AppointmentID = :id");
        $cur->bindParam(":id", $json['appointmentId']);
        $cur->execute();
        $old = $cur->fetch(PDO::FETCH_ASSOC);
        if (!$old) return Validator::fail("That appointment no longer exists.");
        $currentDate = $old['AppointmentDate'];
        // Only enforce "not in the past" when the date/time is being changed, so an old
        // appointment can still be marked Completed / No-Show.
        $dateChanged = ($json['appointmentDate'] ?? null) !== $currentDate;
        $timeChanged = substr($json['appointmentTime'] ?? '', 0, 5) !== $old['T'];
        $relax = $dateChanged ? [] : ['notPast'];
        list($err, $json) = Validator::run("appointment", $json, ['relax' => $relax]);
        if ($err) return Validator::fail($err);
        if (empty($json['status'])) return Validator::fail("Status is required.");
        if (($dateChanged || $timeChanged) && ($e = Validator::timePassedToday($json['appointmentDate'], $json['appointmentTime']))) return Validator::fail($e);
        if ($json['status'] === 'Scheduled' && ($e = $this->findConflict($conn, $json, $json['appointmentId']))) return Validator::fail($e);

        $sql = "UPDATE APPOINTMENT SET
                    PatientID       = :patientId,
                    UserID          = :userId,
                    AppointmentDate = :appointmentDate,
                    AppointmentTime = :appointmentTime,
                    Reason          = :reason,
                    Notes           = :notes,
                    Status          = :status
                WHERE AppointmentID = :appointmentId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":patientId",       $json['patientId']);
        $stmt->bindParam(":userId",          $json['userId']);
        $stmt->bindParam(":appointmentDate", $json['appointmentDate']);
        $stmt->bindParam(":appointmentTime", $json['appointmentTime']);
        $stmt->bindParam(":reason",          $json['reason']);
        $stmt->bindParam(":notes",           $json['notes']);
        $stmt->bindParam(":status",          $json['status']);
        $stmt->bindParam(":appointmentId",   $json['appointmentId']);
        $stmt->execute();

        return Validator::saved($conn, $stmt, 'APPOINTMENT', 'AppointmentID', $json['appointmentId']);
    }

    // Cancel — Admin and Staff only (soft status change)
    function cancelAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if ($e = Validator::badId($json, ['appointmentId'])) return Validator::fail($e);
        $sql = "UPDATE APPOINTMENT SET Status = 'Cancelled' WHERE AppointmentID = :appointmentId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":appointmentId", $json['appointmentId']);
        $stmt->execute();
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }

    // Staff record the intake: Reason, Chief Complaint and Symptoms. The doctor sees
    // these automatically in the consultation and does not re-enter them.
    function saveIntake($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);

        $roleStmt = $conn->prepare("SELECT r.RoleName FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                                    WHERE u.UserID = :id AND u.Status = 'Active'");
        $roleStmt->bindValue(":id", $json['actingUserId'] ?? null);
        $roleStmt->execute();
        if ($roleStmt->fetchColumn() !== 'Staff') return json_encode(["error" => "forbidden"]);

                list($err, $json) = Validator::run("intake", $json, ['nullEmpty' => true]);
        if ($err) return Validator::fail($err);
$cur = $conn->prepare("SELECT Status FROM APPOINTMENT WHERE AppointmentID = :id");
        $cur->bindValue(":id", $json['appointmentId'] ?? null);
        $cur->execute();
        $status = $cur->fetchColumn();
        if ($status === false) return json_encode(["error" => "not_found"]);
        if ($status === 'Cancelled') return json_encode(["error" => "appointment_cancelled"]);

        $stmt = $conn->prepare("UPDATE APPOINTMENT SET
                                    Reason = :reason, ChiefComplaint = :cc, Symptoms = :symptoms
                                WHERE AppointmentID = :id");
        $stmt->bindValue(":reason",   $json['reason']         ?? null);
        $stmt->bindValue(":cc",       $json['chiefComplaint'] ?? null);
        $stmt->bindValue(":symptoms", $json['symptoms']       ?? null);
        $stmt->bindValue(":id",       $json['appointmentId']);
        $stmt->execute();
        return json_encode(1); // rowCount is 0 when nothing changed - still a success
    }

    // Restore a cancelled appointment back to Scheduled (Admin "Restore" button).
    // Only touches rows that are currently Cancelled.
    function restoreAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if ($e = Validator::badId($json, ['appointmentId'])) return Validator::fail($e);
        $row = $conn->prepare("SELECT PatientID, UserID, AppointmentDate, TIME_FORMAT(AppointmentTime, '%H:%i') AS AppointmentTime
                               FROM APPOINTMENT WHERE AppointmentID = :id AND Status = 'Cancelled'");
        $row->bindValue(":id", $json['appointmentId']);
        $row->execute();
        $r = $row->fetch(PDO::FETCH_ASSOC);
        if ($r) {
            $data = ['patientId' => $r['PatientID'], 'userId' => $r['UserID'],
                     'appointmentDate' => $r['AppointmentDate'], 'appointmentTime' => $r['AppointmentTime']];
            if ($r['AppointmentDate'] < Validator::today() || Validator::timePassedToday($r['AppointmentDate'], $r['AppointmentTime']))
                return Validator::fail("This appointment's date and time have already passed, so it can't be set back to Scheduled. Use Edit to change the date instead.");
            if ($e = $this->findConflict($conn, $data, $json['appointmentId'])) return Validator::fail($e);
        }
        $sql = "UPDATE APPOINTMENT SET Status = 'Scheduled'
                WHERE AppointmentID = :appointmentId AND Status = 'Cancelled'";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":appointmentId", $json['appointmentId']);
        $stmt->execute();
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$appt = new Appointment();
switch ($operation) {
    case "getAllAppointments":       echo $appt->getAllAppointments();           break;
    case "getAppointmentsByDoctor": echo $appt->getAppointmentsByDoctor($json); break;
    case "getAppointment":          echo $appt->getAppointment($json);          break;
    case "getActiveDoctors":        echo $appt->getActiveDoctors();             break;
    case "insertAppointment":       echo $appt->insertAppointment($json);       break;
    case "updateAppointment":       echo $appt->updateAppointment($json);       break;
    case "cancelAppointment":       echo $appt->cancelAppointment($json);       break;
    case "restoreAppointment":      echo $appt->restoreAppointment($json);      break;
    case "saveIntake":              echo $appt->saveIntake($json);              break;
}
?>
