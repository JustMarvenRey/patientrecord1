<?php
// Brings an older database up to the schema the current code expects.
// Safe to run repeatedly: each step only runs if its column/constraint is missing,
// and nothing is ever dropped or deleted. Called from connection-pdo.php.
if (!function_exists('ensureSchema')) {
    function ensureSchema($conn) {
        static $done = false;
        if ($done) return;
        $done = true;

        try {
            $db = $conn->query("SELECT DATABASE()")->fetchColumn();

            $has = function ($table, $column = null) use ($conn, $db) {
                if ($column === null) {
                    $q = $conn->prepare("SELECT COUNT(*) FROM information_schema.TABLES
                                         WHERE TABLE_SCHEMA = :db AND TABLE_NAME = :t");
                    $q->execute([":db" => $db, ":t" => $table]);
                } else {
                    $q = $conn->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS
                                         WHERE TABLE_SCHEMA = :db AND TABLE_NAME = :t AND COLUMN_NAME = :c");
                    $q->execute([":db" => $db, ":t" => $table, ":c" => $column]);
                }
                return $q->fetchColumn() > 0;
            };
            $run = function ($sql) use ($conn) {
                try { $conn->exec($sql); } catch (PDOException $e) { error_log("auto-migrate: " . $e->getMessage()); }
            };

            // 1. Staff intake: APPOINTMENT.ChiefComplaint / Symptoms
            if ($has("APPOINTMENT") && !$has("APPOINTMENT", "ChiefComplaint")) {
                $run("ALTER TABLE APPOINTMENT ADD COLUMN ChiefComplaint TEXT NULL, ADD COLUMN Symptoms TEXT NULL");
                if ($has("CONSULTATION")) {
                    $run("UPDATE APPOINTMENT a JOIN CONSULTATION c ON c.AppointmentID = a.AppointmentID
                          SET a.ChiefComplaint = c.ChiefComplaint, a.Symptoms = c.Symptoms");
                }
            }

            // 2. First come, first served: remember WHEN each request was submitted.
            //    (NULL for old rows - their order is still known from AppointmentID.)
            if ($has("APPOINTMENT") && !$has("APPOINTMENT", "CreatedAt")) {
                $run("ALTER TABLE APPOINTMENT ADD COLUMN CreatedAt DATETIME NULL DEFAULT NULL");
            }

            // 3. Vital signs belong to the appointment (recorded by Staff before the consultation)
            if ($has("VITAL_SIGN") && !$has("VITAL_SIGN", "AppointmentID")) {
                $run("ALTER TABLE VITAL_SIGN ADD COLUMN AppointmentID INT NULL AFTER VitalSignID");
                if ($has("CONSULTATION")) {
                    $run("UPDATE VITAL_SIGN v JOIN CONSULTATION c ON c.ConsultationID = v.ConsultationID
                          SET v.AppointmentID = c.AppointmentID");
                }
                $run("ALTER TABLE VITAL_SIGN MODIFY ConsultationID INT NULL");
                $run("ALTER TABLE VITAL_SIGN ADD CONSTRAINT uq_vital_appointment UNIQUE (AppointmentID)");
                $run("ALTER TABLE VITAL_SIGN ADD CONSTRAINT fk_vital_appointment
                      FOREIGN KEY (AppointmentID) REFERENCES APPOINTMENT(AppointmentID)");
            }

            // 4. Specializations are deactivated (soft delete) instead of permanently deleted
            if ($has("SPECIALIZATION") && !$has("SPECIALIZATION", "Status")) {
                $run("ALTER TABLE SPECIALIZATION ADD COLUMN Status VARCHAR(10) NOT NULL DEFAULT 'Active'");
            }
        } catch (PDOException $e) {
            error_log("auto-migrate: " . $e->getMessage());
        }
    }
}
